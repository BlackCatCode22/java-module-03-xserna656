 public class SuperDuper {

     public static void main(String[] args) {

        Cat myCat = new Cat(3, "George", "Purina One");
        System.out.println(myCat.age + " " + myCat.name + " " + myCat.catFoodPreference);

    }
}